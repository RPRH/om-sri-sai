<?php

namespace frontend\models;

use Yii;

/**
 * This is the model class for table "tours".
 *
 * @property integer $tour_id
 * @property string $departure_date
 * @property integer $package_id
 * @property integer $tour_manager_id
 *
 * @property User $tourManager
 * @property Packages $package
 * @property ToursOffers[] $toursOffers
 * @property ToursPnr[] $toursPnrs
 */
class Tours extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'tours';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['departure_date', 'package_id', 'tour_manager_id'], 'required'],
            [['departure_date'], 'safe'],
            [['package_id', 'tour_manager_id'], 'integer']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'tour_id' => 'Tour ID',
            'departure_date' => 'Departure Date',
            'package_id' => 'Package ID',
            'tour_manager_id' => 'Tour Manager ID',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTourManager()
    {
        return $this->hasOne(User::className(), ['id' => 'tour_manager_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPackage()
    {
        return $this->hasOne(Packages::className(), ['package_id' => 'package_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getToursOffers()
    {
        return $this->hasMany(ToursOffers::className(), ['tour_id' => 'tour_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getToursPnrs()
    {
        return $this->hasMany(ToursPnr::className(), ['tour_id' => 'tour_id']);
    }
}
