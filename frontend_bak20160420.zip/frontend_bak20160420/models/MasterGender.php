<?php

namespace frontend\models;

use Yii;

/**
 * This is the model class for table "master_gender".
 *
 * @property integer $gender_id
 * @property string $gender_name
 *
 * @property Passengers[] $passengers
 */
class MasterGender extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'master_gender';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['gender_name'], 'required'],
            [['gender_name'], 'string', 'max' => 65]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'gender_id' => 'Gender ID',
            'gender_name' => 'Gender Name',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPassengers()
    {
        return $this->hasMany(Passengers::className(), ['gender' => 'gender_id']);
    }
}
