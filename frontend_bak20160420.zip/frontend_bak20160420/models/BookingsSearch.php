<?php

namespace frontend\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use frontend\models\Bookings;

/**
 * BookingsSearch represents the model behind the search form about `frontend\models\Bookings`.
 */
class BookingsSearch extends Bookings
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'user_id', 'mode_of_payment', 'agent_id', 'booking_status', 'tour_id'], 'integer'],
            [['booking_datetime', 'emergency_contact', 'emergency_email', 'remarks'], 'safe'],
            [['tax', 'discount', 'additional_charges', 'total_amount'], 'number'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Bookings::find();

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        $query->andFilterWhere([
            'id' => $this->id,
            'user_id' => $this->user_id,
            'booking_datetime' => $this->booking_datetime,
            'mode_of_payment' => $this->mode_of_payment,
            'tax' => $this->tax,
            'discount' => $this->discount,
            'additional_charges' => $this->additional_charges,
            'total_amount' => $this->total_amount,
            'agent_id' => $this->agent_id,
            'booking_status' => $this->booking_status,
            'tour_id' => $this->tour_id,
        ]);

        $query->andFilterWhere(['like', 'emergency_contact', $this->emergency_contact])
            ->andFilterWhere(['like', 'emergency_email', $this->emergency_email])
            ->andFilterWhere(['like', 'remarks', $this->remarks]);

        return $dataProvider;
    }
}
