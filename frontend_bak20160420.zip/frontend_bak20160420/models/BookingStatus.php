<?php

namespace frontend\models;

use Yii;

/**
 * This is the model class for table "booking_status".
 *
 * @property integer $id
 * @property string $status_type
 *
 * @property Bookings[] $bookings
 */
class BookingStatus extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'booking_status';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['status_type'], 'required'],
            [['status_type'], 'string', 'max' => 65]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'status_type' => 'Status Type',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getBookings()
    {
        return $this->hasMany(Bookings::className(), ['booking_status' => 'id']);
    }
}
