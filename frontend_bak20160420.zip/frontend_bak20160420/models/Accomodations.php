<?php

namespace frontend\models;

use Yii;

/**
 * This is the model class for table "accomodations".
 *
 * @property integer $accomodation_id
 * @property integer $booking_id
 * @property integer $two_Bedded
 * @property integer $three_Bedded
 *
 * @property Bookings $booking
 */
class Accomodations extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'accomodations';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['booking_id', 'two_Bedded', 'three_Bedded'], 'required'],
            [['booking_id', 'two_Bedded', 'three_Bedded'], 'integer']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'accomodation_id' => 'Accomodation ID',
            'booking_id' => 'Booking ID',
            'two_Bedded' => 'Two  Bedded',
            'three_Bedded' => 'Three  Bedded',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getBooking()
    {
        return $this->hasOne(Bookings::className(), ['id' => 'booking_id']);
    }
}
