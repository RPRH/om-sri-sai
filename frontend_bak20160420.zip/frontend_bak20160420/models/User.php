<?php

namespace frontend\models;

use yii\db\ActiveRecord;
use Yii;

/**
 * This is the model class for table "user".
 *
 * @property integer $id
 * @property string $firstname
 * @property string $middlename
 * @property string $lastname
 * @property string $auth_key
 * @property string $email
 * @property string $phone
 * @property string $address
 * @property string $password_hash
 * @property string $password_reset_token
 * @property integer $user_type
 * @property integer $status
 * @property string $created_at
 * @property string $updated_at
 *
 * @property Agents[] $agents
 * @property Bookings[] $bookings
 * @property Bookings[] $bookings0
 * @property Passengers[] $passengers
 * @property Payments[] $payments
 * @property Tours[] $tours
 * @property UserCategories $userType
 * @property UserStatus $status0
 */
class User extends ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'user';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['firstname', 'lastname', 'email', 'phone', 'address', 'user_type', 'status'], 'required'],
            [['address'], 'string'],
            [['user_type', 'status'], 'integer'],
            [['created_at', 'updated_at'], 'safe'],
            [['firstname', 'middlename', 'lastname'], 'string', 'max' => 65],
            [['auth_key'], 'string', 'max' => 32],
            [['email', 'password_hash', 'password_reset_token'], 'string', 'max' => 255],
            [['phone'], 'string', 'max' => 15],
            [['email'], 'unique'],
            [['email'], 'email'],
            [['password_reset_token'], 'unique']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'firstname' => 'Firstname',
            'middlename' => 'Middlename',
            'lastname' => 'Lastname',
            'auth_key' => 'Auth Key',
            'email' => 'Email',
            'phone' => 'Phone',
            'address' => 'Address',
            'password_hash' => 'Password Hash',
            'password_reset_token' => 'Password Reset Token',
            'user_type' => 'User Type',
            'status' => 'Status',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getAgents()
    {
        return $this->hasMany(Agents::className(), ['agent_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getBookings()
    {
        return $this->hasMany(Bookings::className(), ['agent_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getBookings0()
    {
        return $this->hasMany(Bookings::className(), ['user_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPassengers()
    {
        return $this->hasMany(Passengers::className(), ['user_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPayments()
    {
        return $this->hasMany(Payments::className(), ['cashier_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTours()
    {
        return $this->hasMany(Tours::className(), ['tour_manager_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUserType()
    {
        return $this->hasOne(UserCategories::className(), ['id' => 'user_type']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getStatus0()
    {
        return $this->hasOne(UserStatus::className(), ['id' => 'status']);
    }
}
