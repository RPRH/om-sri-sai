<?php

namespace frontend\models;

use common\models\User;
use yii\base\Model;
use Yii;

/**
 * Signup form
 */
class SignupForm extends Model {

//  public $username;
    public $firstname;
    public $middlename;
    public $lastname;
    public $email;
    public $phone;
    public $address;
    public $user_type;
    public $password;
    public $password_repeat;
    public $created_at;
    public $updated_at;

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
//            ['username', 'filter', 'filter' => 'trim'],
//            ['username', 'required'],
//            ['username', 'unique', 'targetClass' => '\common\models\User', 'message' => 'This username has already been taken.'],
//            ['username', 'string', 'min' => 2, 'max' => 65],

            ['firstname', 'required'],
            ['firstname', 'string', 'min' => 2, 'max' => 65],
            ['middlename', 'string', 'min' => 2, 'max' => 65],
            ['lastname', 'required'],
            ['lastname', 'string', 'min' => 2, 'max' => 65],
            ['email', 'filter', 'filter' => 'trim'],
            ['email', 'required'],
            ['email', 'email'],
            ['email', 'string', 'max' => 65],
            ['email', 'unique', 'targetClass' => '\common\models\User', 'message' => 'This email address has already been taken.'],
            ['phone', 'required'],
            ['phone', 'string', 'min' => 10, 'max' => 15],
            ['password', 'required'],
            ['password', 'string', 'min' => 6],
            ['password_repeat', 'compare', 'compareAttribute' => 'password'],
            ['password_repeat', 'safe'],
            ['password_repeat', 'required'],
            [['address'], 'string'],
            ['address', 'required'],
            [['user_type'], 'integer'],
            [['created_at', 'updated_at'], 'safe'],
            [['created_at', 'updated_at'], 'string'],
        ];
    }

    /**
     * Signs user up.
     *
     * @return User|null the saved model or null if saving fails
     */
    public function signup() {
        if (!$this->validate()) {
            return null;
        }
        $user = new User();
//      $user->username = $this->username;
        $user->firstname = $this->firstname;
        $user->middlename = $this->middlename;
        $user->lastname = $this->lastname;
        $user->email = $this->email;
        $user->phone = $this->phone;
        $user->address = $this->address;
        $user->user_type = 3;
        $user->setPassword($this->password);
        $user->created_at = $this->created_at = date('Y-m-d h:m:s');
        $user->updated_at = $this->updated_at = date('Y-m-d h:m:s');
        $user->generateAuthKey();
        $user->save();
        return $user;
    }

}
