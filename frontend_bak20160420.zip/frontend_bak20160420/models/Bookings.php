<?php

namespace frontend\models;

use yii\db\ActiveRecord;
use Yii;

/**
 * This is the model class for table "bookings".
 *
 * @property integer $id
 * @property integer $user_id
 * @property string $booking_datetime
 * @property string $emergency_contact
 * @property string $emergency_email
 * @property integer $mode_of_payment
 * @property string $tax
 * @property string $discount
 * @property string $additional_charges
 * @property string $remarks
 * @property string $total_amount
 * @property integer $agent_id
 * @property integer $booking_status
 * @property integer $tour_id
 *
 * @property Accomodations[] $accomodations
 * @property User $agent
 * @property Tours $tour
 * @property MasterModeOfPayment $modeOfPayment
 * @property BookingStatus $bookingStatus
 * @property User $user
 * @property Passengers[] $passengers
 * @property Payments[] $payments
 */
class Bookings extends ActiveRecord
{
    public $agree = false;
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'bookings';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['agree'], 'boolean'],
            ['agree', 'compare', 'compareValue' => true, 'message' => 'You must agree to the terms and conditions'],
            [['agree', 'booking_datetime', 'emergency_contact', 'emergency_email', 'mode_of_payment', 'total_amount', 'booking_status', 'tour_id'], 'required'],
            [['mode_of_payment', 'booking_status', 'tour_id'], 'integer'],
            [['booking_datetime'], 'safe'],
            [['tax', 'discount', 'additional_charges', 'total_amount'], 'number'],
            [['remarks'], 'string'],
            [['emergency_contact'], 'string', 'max' => 15],
            [['emergency_email'], 'string', 'max' => 65],
            [['emergency_email'],'email']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'agree' => 'I agree to terms and conditions',
            'id' => 'Booking ID',
            'user_id' => 'User ID',
            'booking_datetime' => 'Booking Datetime',
            'emergency_contact' => 'Emergency Contact',
            'emergency_email' => 'Emergency Email',
            'mode_of_payment' => 'Mode Of Payment',
            'tax' => 'Tax',
            'discount' => 'Discount',
            'additional_charges' => 'Additional Charges',
            'remarks' => 'Remarks',
            'total_amount' => 'Total Amount',
            'agent_id' => 'Agent Name',
            'booking_status' => 'Booking Status',
            'tour_id' => 'Tour ID',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getAccomodations()
    {
        return $this->hasMany(Accomodations::className(), ['booking_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getAgent()
    {
        return $this->hasOne(User::className(), ['id' => 'agent_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTour()
    {
        return $this->hasOne(Tours::className(), ['tour_id' => 'tour_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getModeOfPayment()
    {
        return $this->hasOne(MasterModeOfPayment::className(), ['mop_id' => 'mode_of_payment']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getBookingStatus()
    {
        return $this->hasOne(BookingStatus::className(), ['id' => 'booking_status']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUser()
    {
        return $this->hasOne(User::className(), ['id' => 'user_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPassengers()
    {
        return $this->hasMany(Passengers::className(), ['booking_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPayments()
    {
        return $this->hasMany(Payments::className(), ['booking_id' => 'id']);
    }
    
    public static function createMultiple($modelClass, $multipleModels = [])
    {
        $model    = new $modelClass;
        $formName = $model->formName();
        $post     = Yii::$app->request->post($formName);
        $models   = [];

        if (! empty($multipleModels)) {
            $keys = array_keys(ArrayHelper::map($multipleModels, 'id', 'id'));
            $multipleModels = array_combine($keys, $multipleModels);
        }

        if ($post && is_array($post)) {
            foreach ($post as $i => $item) {
                if (isset($item['id']) && !empty($item['id']) && isset($multipleModels[$item['id']])) {
                    $models[] = $multipleModels[$item['id']];
                } else {
                    $models[] = new $modelClass;
                }
            }
        }

        unset($model, $formName, $post);

        return $models;
    }
}
