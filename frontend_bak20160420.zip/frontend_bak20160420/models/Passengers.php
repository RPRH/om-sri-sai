<?php

namespace frontend\models;

use yii\db\ActiveRecord;
use Yii;

/**
 * This is the model class for table "passengers".
 *
 * @property integer $id
 * @property integer $user_id
 * @property string $firstname
 * @property string $lastname
 * @property string $email
 * @property string $phone
 * @property integer $age
 * @property integer $gender
 * @property integer $id_proof_type
 * @property string $id_proof_number
 * @property integer $booking_id
 *
 * @property MasterGender $gender0
 * @property MasterIdProof $idProofType
 * @property User $user
 * @property Bookings $booking
 */
class Passengers extends ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'passengers';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['firstname', 'lastname', 'email', 'phone', 'age', 'gender', 'id_proof_type', 'id_proof_number'], 'required'],
            [['age', 'gender', 'id_proof_type'], 'integer'],
            [['firstname', 'lastname', 'email'], 'string', 'max' => 65],
            [['phone', 'id_proof_number'], 'string', 'max' => 15],
            [['email'],'email']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'user_id' => 'User ID',
            'firstname' => 'Firstname',
            'lastname' => 'Lastname',
            'email' => 'Email',
            'phone' => 'Phone',
            'age' => 'Age',
            'gender' => 'Gender',
            'id_proof_type' => 'ID Proof',
            'id_proof_number' => 'ID Proof Number',
            'booking_id' => 'Booking ID',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getGender0()
    {
        return $this->hasOne(MasterGender::className(), ['gender_id' => 'gender']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdProofType()
    {
        return $this->hasOne(MasterIdProof::className(), ['proof_id' => 'id_proof_type']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUser()
    {
        return $this->hasOne(User::className(), ['id' => 'user_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getBooking()
    {
        return $this->hasOne(Bookings::className(), ['id' => 'booking_id']);
    }
}
