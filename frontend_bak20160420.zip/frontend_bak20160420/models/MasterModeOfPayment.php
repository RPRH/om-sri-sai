<?php

namespace frontend\models;

use Yii;

/**
 * This is the model class for table "master_mode_of_payment".
 *
 * @property integer $mop_id
 * @property string $mop_name
 *
 * @property Bookings[] $bookings
 * @property Payments[] $payments
 */
class MasterModeOfPayment extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'master_mode_of_payment';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['mop_name'], 'required'],
            [['mop_name'], 'string', 'max' => 65]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'mop_id' => 'Mop ID',
            'mop_name' => 'Mop Name',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getBookings()
    {
        return $this->hasMany(Bookings::className(), ['mode_of_payment' => 'mop_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPayments()
    {
        return $this->hasMany(Payments::className(), ['payment_mode_id' => 'mop_id']);
    }
}
