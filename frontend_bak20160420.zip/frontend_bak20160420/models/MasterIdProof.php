<?php

namespace frontend\models;

use Yii;

/**
 * This is the model class for table "master_id_proof".
 *
 * @property integer $proof_id
 * @property string $proof_name
 *
 * @property Passengers[] $passengers
 */
class MasterIdProof extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'master_id_proof';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['proof_name'], 'required'],
            [['proof_name'], 'string', 'max' => 65]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'proof_id' => 'Proof ID',
            'proof_name' => 'Proof Name',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPassengers()
    {
        return $this->hasMany(Passengers::className(), ['id_proof_type' => 'proof_id']);
    }
}
