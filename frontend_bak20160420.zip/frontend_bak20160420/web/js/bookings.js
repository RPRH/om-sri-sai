jQuery(function () {
    jQuery('#passengers-0-firstname').one('click', function () {
        document.getElementById("passengers-0-firstname").value = document.getElementById("user-firstname").value;
        document.getElementById("passengers-0-lastname").value = document.getElementById("user-lastname").value;
        document.getElementById("passengers-0-email").value = document.getElementById("user-email").value;
        document.getElementById("passengers-0-phone").value = document.getElementById("user-phone").value;
    });
    jQuery(".remove-item").hide();
    jQuery(".bookings-form").on("keyup", function () {
        var agesEmpty0 = jQuery("#passengers-0-age").val();
        jQuery("#passengers-0-age").parent().siblings().children(".remove-item").click(function () {
            document.getElementById("passengers-0-age").value = "";
            jQuery("#passengers-0-age").keyup();
        });
        var agesEmpty1 = jQuery("#passengers-1-age").val();
        jQuery("#passengers-1-age").parent().siblings().children(".remove-item").click(function () {
            document.getElementById("passengers-1-age").value = "";
            jQuery("#passengers-1-age").keyup();
        });
        var agesEmpty2 = jQuery("#passengers-2-age").val();
        jQuery("#passengers-2-age").parent().siblings().children(".remove-item").click(function () {
            document.getElementById("passengers-2-age").value = "";
            jQuery("#passengers-2-age").keyup();
        });
        var agesEmpty3 = jQuery("#passengers-3-age").val();
        jQuery("#passengers-3-age").parent().siblings().children(".remove-item").click(function () {
            document.getElementById("passengers-3-age").value = "";
            jQuery("#passengers-3-age").keyup();
        });
        var agesEmpty4 = jQuery("#passengers-4-age").val();
        jQuery("#passengers-4-age").parent().siblings().children(".remove-item").click(function () {
            document.getElementById("passengers-4-age").value = "";
            jQuery("#passengers-4-age").keyup();
        });
        var agesEmpty5 = jQuery("#passengers-5-age").val();
        jQuery("#passengers-5-age").parent().siblings().children(".remove-item").click(function () {
            document.getElementById("passengers-5-age").value = "";
            jQuery("#passengers-5-age").keyup();
        });
        var agesEmpty6 = jQuery("#passengers-6-age").val();
        jQuery("#passengers-6-age").parent().siblings().children(".remove-item").click(function () {
            document.getElementById("passengers-6-age").value = "";
            jQuery("#passengers-6-age").keyup();
        });
        var agesEmpty7 = jQuery("#passengers-7-age").val();
        jQuery("#passengers-7-age").parent().siblings().children(".remove-item").click(function () {
            document.getElementById("passengers-7-age").value = "";
            jQuery("#passengers-7-age").keyup();
        });
        var agesEmpty8 = jQuery("#passengers-8-age").val();
        jQuery("#passengers-8-age").parent().siblings().children(".remove-item").click(function () {
            document.getElementById("passengers-8-age").value = "";
            jQuery("#passengers-8-age").keyup();
        });

        var agesEmpty9 = jQuery("#passengers-9-age").val();
        jQuery("#passengers-9-age").parent().siblings().children(".remove-item").click(function () {
            document.getElementById("passengers-9-age").value = "";
            jQuery("#passengers-9-age").keyup();
        });

        var agesEmpty = [];
        if (agesEmpty0 != "") {
            agesEmpty.push(agesEmpty0);
        }
        if (agesEmpty1 != "") {
            agesEmpty.push(agesEmpty1);
        }
        if (agesEmpty2 != "") {
            agesEmpty.push(agesEmpty2);
        }
        if (agesEmpty3 != "") {
            agesEmpty.push(agesEmpty3);
        }
        if (agesEmpty4 != "") {
            agesEmpty.push(agesEmpty4);
        }
        if (agesEmpty5 != "") {
            agesEmpty.push(agesEmpty5);
        }
        if (agesEmpty6 != "") {
            agesEmpty.push(agesEmpty6);
        }
        if (agesEmpty7 != "") {
            agesEmpty.push(agesEmpty7);
        }
        if (agesEmpty8 != "") {
            agesEmpty.push(agesEmpty8);
        }
        if (agesEmpty9 != "") {
            agesEmpty.push(agesEmpty9);
        }
        var ages = agesEmpty.length;

        if (ages > 0) {
            var infant = 0;
            var kid = 0;
            var adult = 0;
            var get_bed = 0;
            jQuery.each(agesEmpty, function (index, value) {
                if (value > 0 && value <= 2) {
                    infant++;
                } else if (value > 2 && value <= 4) {
                    kid++;
                } else if (value > 4) {
                    adult++;
                }
                if (value > 8) {
                    get_bed++;
                }

            });

            jQuery("#adult_count").html(adult);
            jQuery("#kid_count").html(kid);
            jQuery("#infant_count").html(infant);

            if (adult > 0) {
                jQuery(".adult_dp").css("display", "block");
            } else {
                jQuery(".adult_dp").css("display", "none");
            }
            if (kid > 0) {
                jQuery(".kid_dp").css("display", "block");
            } else {
                jQuery(".kid_dp").css("display", "none");
            }
            if (infant > 0) {
                jQuery(".infant_dp").css("display", "block");
            } else {
                jQuery(".infant_dp").css("display", "none")
            }

            if (adult == 1) {
                var twin_share = adult * 12250;
                jQuery("#adult_price").html(twin_share);
                jQuery("#ad_price").html("12250");

            } else {
                var twin_share = adult * 10999;
                jQuery("#adult_price").html(twin_share);
                jQuery("#ad_price").html("10999");
            }
            var kid_tp = kid * 8000;
            var infant_tp = infant * 2500;
            jQuery("#kid_price").html(kid_tp);
            jQuery("#infant_price").html(infant_tp);

            var total_price = twin_share + kid_tp + infant_tp;
            document.getElementById("bookings-total_amount").value = total_price;

            var x = get_bed;
            document.getElementById("accomodations-two_bedded").defaultValue = 0;
            document.getElementById("accomodations-three_bedded").defaultValue = 0;
            if (x % 3 == 0) {
                var threebeds = 0;
                var j = 3;
                for (var j; j <= x; j++) {
                    j = j + 2;
                    threebeds++;
                }
                document.getElementById("accomodations-three_bedded").value = threebeds;
                document.getElementById("accomodations-two_bedded").value = 0;
            } else if (x % 2 == 0) {
                var twobeds = 0;
                var i = 2;
                for (var i; i <= x; i++) {
                    i = i + 1;
                    twobeds++;
                }
                document.getElementById("accomodations-two_bedded").value = twobeds;
                document.getElementById("accomodations-three_bedded").value = 0;
            } else if (x % 2 != 0 && x % 3 != 0) {
                if (x == 1) {
                    document.getElementById("accomodations-two_bedded").value = 1;
                }
                var quo_beds = parseInt(x / 3);
                var rem_beds = 0;
                if (quo_beds > 0) {
                    var threebeds = 0;
                    var k = 3;
                    for (var k; k <= x; k++) {
                        k = k + 3;
                        threebeds++;
                    }
                    var totalthreebeds = threebeds * 3;
                    if (totalthreebeds != x) {
                        rem_beds++;
                    }
                    document.getElementById("accomodations-three_bedded").value = threebeds;
                    document.getElementById("accomodations-two_bedded").value = rem_beds;
                }
            }
        } else if (ages <= 0) {
            document.getElementById("accomodations-three_bedded").value = 0;
            document.getElementById("accomodations-two_bedded").value = 0;
        }
    });
});