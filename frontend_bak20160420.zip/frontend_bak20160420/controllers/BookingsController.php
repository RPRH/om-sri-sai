<?php

namespace frontend\controllers;

use Yii;
use frontend\models\Bookings;
use frontend\models\BookingsSearch;
//use frontend\models\User;
use frontend\models\Passengers;
use frontend\models\PassengersSearch;
use frontend\models\Accomodations;
use frontend\models\AccomodationsSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * BookingsController implements the CRUD actions for Bookings model.
 */
class BookingsController extends Controller {

    public function behaviors() {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all Bookings models.
     * @return mixed
     */
    public function actionIndex() {
        $searchModel = new BookingsSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Bookings model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id) {
        $model = $this->findModel($id);
        $model2 = $model->passengers;
        $model3 = $model->accomodations;

        $searchModel = new PassengersSearch();
        $searchModel->booking_id = $model->id;
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        $searchModel1 = new AccomodationsSearch();
        $searchModel1->booking_id = $model->id;
        $dataProvider1 = $searchModel1->search(Yii::$app->request->queryParams);


        return $this->render('view', [
                    'model' => $model,
                    'model2' => $model2,
                    'model3' => $model3,
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
                    'searchModel1' => $searchModel1,
                    'dataProvider1' => $dataProvider1,
        ]);
    }

    /**
     * Creates a new Bookings model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate() {
        $model = new Bookings();
        $model2 = [new Passengers];
        $model3 = new Accomodations();
        //$model4 = new User();

        if ($model->load(Yii::$app->request->post())) {
            $model->attributes = $_POST['Bookings'];
            //$model2->attributes = $_POST['Passengers'];
            $model3->attributes = $_POST['Accomodations'];
//          $model4->attributes = $_POST['User'];
//          $model4->password_hash = "NULL";
//          $model4->user_type = 3;
//          $model4->status = 4;
//          $model4->created_at = date('Y-m-d h:m:s');
//          $model4->updated_at = date('Y-m-d h:m:s');
//          $model4->save();

            $model->user_id = Yii::$app->user->getId();
            $model->booking_datetime = date('Y-m-d h:m:s');
            $model->agent_id = Yii::$app->user->getId();
            $model->booking_status = 1;
            $model->tax = 0;
            $model->discount = 0;
            $model->additional_charges = 0;
            $model->save();
            //$model2->user_id = Yii::$app->user->getId();
            //$model2->booking_id = $model->id;
            //$model2->save();
            $model3->booking_id = $model->id;
            $model3->save();

            $model2 = Bookings::createMultiple(Passengers::classname());
            Bookings::loadMultiple($model2, Yii::$app->request->post());

            // ajax validation
            /* if (Yii::$app->request->isAjax) {
              Yii::$app->response->format = Response::FORMAT_JSON;
              return ArrayHelper::merge(
              ActiveForm::validateMultiple($model2), ActiveForm::validate($model)
              );
              } */

            // validate all models
            $valid = $model->validate();
            $valid = Bookings::validateMultiple($model2) && $valid;

            if ($valid) {
                $transaction = \Yii::$app->db->beginTransaction();
                try {
                    if ($flag = $model->save(false)) {
                        foreach ($model2 as $modelAdd) {
                            $modelAdd->user_id = Yii::$app->user->getId();
                            $modelAdd->booking_id = $model->id;
                            if (!($flag = $modelAdd->save(false))) {
                                $transaction->rollBack();
                                break;
                            }
                        }
                    }
                    if ($flag) {
                        $transaction->commit();
                        return $this->redirect(['view', 'id' => $model->id]);
                    }
                } catch (Exception $e) {
                    $transaction->rollBack();
                }
            }
        } else {
            return $this->render('create', [
                        'model' => $model,
                        'model2' => (empty($model2)) ? [new Passengers] : $model2,
                        'model3' => $model3,
                        //'model4' => $model4,
            ]);
        }
    }

    /**
     * Updates an existing Bookings model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id) {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('update', [
                        'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing Bookings model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id) {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Bookings model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Bookings the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id) {
        if (($model = Bookings::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

}
