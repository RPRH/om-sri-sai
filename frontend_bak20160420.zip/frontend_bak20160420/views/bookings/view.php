<?php

//use yii\helpers\Html;
use yii\widgets\DetailView;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $model backend\models\Bookings */

$this->title = 'Booking Summary';
//$this->params['breadcrumbs'][] = ['label' => 'Bookings', 'url' => ['index']];
//$this->params['breadcrumbs'][] = $this->title;
?>
<div class="bookings-view">
    <div class="row iv_hdr">
        <div class="col-md-12">
            <h3 class="left">Tour Booking Invoice</h3>
            <h3 class="right">saishubtours.in</h3>
        </div>

        <div class="col-md-5">
            <img src="http://saishubtours.in/wp/wp-content/uploads/2016/03/saishublogo-1.jpg" alt="Logo">
        </div> 
        <div class="col-md-7 iv_hdr_adr right_align">
            <h4>Address</h4>
            <p>NO 44, 1ST FLOOR, 4TH CROSS, PARALLEL TO HALLIMANE HOTEL, SAMPIGE ROAD, MALLESHWARAM, BANGALORE -560003</p>
            <h4>Phone</h4>
            <p>+91 9535644533, +91 9902851199, 080-40992132</p>
            <div class="col-md-6">
                <h4>Website</h4>
                <p><a href="http://saishubtours.in">www.saishubtours.in</a></p>
            </div>
            <div class="col-md-6">
                <h4>Email</h4>
                <p><a href="mailto:saishubtours@gmail.com">info@saishubtours.in</a></p>
            </div>
        </div>
    </div>
<!--    <p>
 Html::a('Update', ['update', 'id' => $model->id], ['class' => 'btn btn-primary'])

Html::a('Delete', ['delete', 'id' => $model->id], [
    'class' => 'btn btn-danger',
    'data' => [
        'confirm' => 'Are you sure you want to delete this item?',
        'method' => 'post',
    ],
])
            
</p>-->
      <h4> Booking Details </h4>
       <div class="row cstmr_detl">
                <div class="col-md-9">
    <?=
    DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            //'user_id',
            'emergency_contact',
            'emergency_email:email',
            //'remarks:ntext',
            [
                'attribute' => 'agent_id',
                'value' => $model->agent->firstname,
            ],
        //'tour_id',
        ],
    ])
    ?>
  </div> 
                <div class="col-md-3 center_align">
    <?=
    DetailView::widget([
        'model' => $model,
        'attributes' => [
            'booking_datetime',
        //'tour_id',
        ],
    ])
    ?>
</div>
            </div>
            
            <div class="row cnfm_detl">
                <div class="col-md-5 center_align">

    <?=
    DetailView::widget([
        'model' => $model,
        'attributes' => [
            [
                'attribute' => 'booking_status',
                'value' => $model->bookingStatus->status_type,
            ],
        //'tour_id',
        ],
    ])
    ?>
</div>
    <div class="col-md-7">

    <?=
    DetailView::widget([
        'model' => $model,
        'attributes' => [
            'tax',
            'discount',
            'additional_charges',
            'total_amount',
            [
                'attribute' => 'mode_of_payment',
                'value' => $model->modeOfPayment->mop_name,
            ],
        ],
    ])
    ?>
</div>
</div>
    <h4> Traveler Details </h4>
    <?=
    GridView::widget([
        'dataProvider' => $dataProvider,
        //'filterModel' => $searchModel,
        'columns' => [
            'firstname',
            'lastname',
            'email',
            'phone',
            'age',
            [
                'attribute' => 'gender',
                'value' => 'gender0.gender_name',
            ],
            [
                'attribute' => 'id_proof_type',
                'value' => 'idProofType.proof_name'
            ],
        ],
    ])
    ?>

    <h4> Accommodation Details </h4>
    <?=
    GridView::widget([
        'dataProvider' => $dataProvider1,
        //'filterModel' => $searchModel,
        'columns' => [
            'two_Bedded',
            'three_Bedded',
        ],
    ])
    ?>    
<div class="row terms_conditions">
        <h5 class="center_align">Terms and Conditions</h5>
        <h2>Tour Schedule</h2>
        <h4 class="dark_red"><i>Tour Manager details will be sent to your mobile one day prior to Package date</i></h4>
        <h4 class="green">Day 1</h4>
        <ul>
            <li>Report at Bangalore Airport at 4.00am, flight depart at 5.30 am and arrival @ Pune at 6.40 am.</li>
            <li>Buffet breakfast at Pune (Shiv Sagar) at 7.30 am</li>
            <li>Proceed to Uttarakshetra Balaji Temple (50 km from Pune) have darshan at 10.00am and return to Pune. Have Lunch at Shiv Sagar Pune at 12.30 pm and proceed towards Shirdi.</li>
            <li>On the way visit the famous Udbavamurthi Ganapathi temple at Ranjangav at 2.30pm</li>
            <li>Reach Shirdi at 5.30 pm and have Hitea – then take rest/fresh up </li>
            <li><b>Special Sai darshan at 7.30 pm</b> and then have Buffet dinner at Restaurant at 9.30pm</li>
        </ul>
        <h4 class="green">Day 2</h4>
        <ul>
            <li>At 8.00 am have buffet breakfast at lodge</li>
            <li>Second day <b>Special Sai darshan</b> and free time for shopping up to 1.00pm</li>
            <li>Departure from Shirdi at 01.30 pm after Lunch</li>
            <li>Enroute Visit the famous Shanisinganapur shani bhagwan temple at 4.30 pm have darshan and proceed towards pune</li>
            <li>Dinner at Pune & departure by Flight to your Destination at 9.50 pm, reach Bangalore at 11.00 pm</li>
        </ul>
    </div>

    <div class="row t_c dark_red">
        <div class="col-md-3"><b>T & C</b></div>
        <div class="col-md-9"><b>Use Booking id for all future communication</b></div>
    </div>
    <div class="row box_ctnt border_full">
        <ul>
            <li>Package is from Airport to Airport, its All Inclusive, “ NO HIDDEN COST WHATSOEVER”. Name as to be given as per ID proof, as it verifiable at Airport entry, if any correction, do inform within 3 days of confirmation and maximum before 10 days of travel date. If any mistakes in name at Airport, consequences has responsibility of Passenger only. Once booked and confirmed “No Cancel or Refund”. Documents to carry : Photo ID proof : Election ID card/ Driving license/Birth certificate or School ID for children’s Tour manager/accompany details will be sent one day before the travel date through message(sms. Its Pilgrimage tour, alcohol and smoking is strictly prohibited and only veg food served. Organizer reserves all rights to make any emergency changes with notice.</li>
            <li><p><b>Unavoidable Circumstances:</b></p>
                If due to reasons beyond our control like riots, flood, political unrest, bandhs, accidents or any other natural or man made calamities, the program of the tour has to be changed or extended, the additional expenditure for the same will have to be borne by the passengers. <b>If flight miss on unavoidable situation, return to starting destination will be by Vovlo Multi axile bus on same night on immediate availability only.</b> If any passengers, has to leave the tour mid-way due to any reasons like death of relative, or illness or any other reasons, there shall be no refund for the remaining portion of the tour.</li>
        </ul>   
    </div>
</div>
