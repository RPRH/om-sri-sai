<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel backend\models\BookingsSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Bookings';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="bookings-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Create Bookings', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?=
    GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            //['class' => 'yii\grid\SerialColumn'],
            'id',
            ['attribute' => 'user_id',
                'value' => 'user.firstname',
            ],
            ['attribute' => 'email',
                'value' => 'user.email',
            ],
            ['attribute' => 'phone',
                'value' => 'user.phone',
            ],
            'booking_datetime',
            //'emergency_contact',
            //'emergency_email:email',
            // 'mode_of_payment',
            // 'tax',
            // 'discount',
            // 'additional_charges',
            // 'remarks:ntext',
            ['attribute' => 'agent_id',
                'value' => 'agent.firstname',
            ],
            // 'booking_status',
            // 'tour_id',
            'total_amount',
            ['attribute' => 'booking_status',
                'value' => 'bookingStatus.status_type',
            ],
            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]);
    ?>

</div>
