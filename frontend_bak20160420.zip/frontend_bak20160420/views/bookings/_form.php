<?php
use yii\helpers\Html;
//use yii\widgets\ActiveForm;
use kartik\form\ActiveForm;
use yii\helpers\ArrayHelper;
use frontend\models\Tours;
use frontend\models\MasterGender;
use frontend\models\MasterIdProof;
use wbraganca\dynamicform\DynamicFormWidget;

/* @var $this yii\web\View */
/* @var $model frontend\models\Bookings */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="bookings-form">

    <?php
    $form = ActiveForm::begin([
                'type' => ActiveForm::TYPE_INLINE,
                'formConfig' => ['showErrors' => true],
                'id' => 'dynamic-form']);
    ?>
    <div class="panel panel-default"><br/><br/>
        <div class="panel-body text-center">
<!--        $form->field($model4, 'firstname')->textInput(['maxlength' => true])

            $form->field($model4, 'lastname')->textInput(['maxlength' => true])

            $form->field($model4, 'email')->textInput(['maxlength' => true])

            $form->field($model4, 'phone')->textInput(['maxlength' => true]) 

            $form->field($model4, 'address')->textInput(['maxlength' => true])-->

            <?= $form->field($model, 'tour_id')->dropDownList(ArrayHelper::map(Tours::find()->all(), 'tour_id', 'departure_date'), ['prompt' => 'Select Tour Date']) ?>

        </div>
        <div class="panel-heading"><h3 class="panel-title">Traveler Details</h3></div>
        <div class="panel-body">
            <?php
            DynamicFormWidget::begin([
                'widgetContainer' => 'dynamicform_wrapper', // required: only alphanumeric characters plus "_" [A-Za-z0-9_]
                'widgetBody' => '.container-items', // required: css class selector
                'widgetItem' => '.item', // required: css class
                'limit' => 10, // the maximum times, an element can be cloned (default 999)
                'min' => 1, // 0 or 1 (default 1)
                'insertButton' => '.add-item', // css class
                'deleteButton' => '.remove-item', // css class
                'model' => $model2[0],
                'formId' => 'dynamic-form',
                'formFields' => [
                    'firstname',
                    'middlename',
                    'lastname',
                    'email',
                    'phone',
                    'age',
                    'gender',
                    'id_proof_type',
                    'id_proof_number',
                ],
            ]);
            ?>
            <div class="container-items"><!-- widget Container -->
                <?php foreach ($model2 as $i => $modelAdd): ?>
                    <div class="item panel panel-default text-center"><br/><!-- widget Body -->
                        <!--<div class="panel-body">-->
                        <?php
                        // necessary for update action.
                        if (!$modelAdd->isNewRecord) {
                            echo Html::activeHiddenInput($modelAdd, "[{$i}]id");
                        }
                        ?>
                        <?= $form->field($modelAdd, "[{$i}]firstname")->textInput(['maxlength' => true, 'style' => 'width:10em']) ?>

                        <?= $form->field($modelAdd, "[{$i}]lastname")->textInput(['maxlength' => true, 'style' => 'width:10em']) ?>
                        
                        <?= $form->field($modelAdd, "[{$i}]email")->textInput(['maxlength' => true]) ?>

                        <?= $form->field($modelAdd, "[{$i}]phone")->textInput(['maxlength' => true, 'style' => 'width:10em']) ?>

                        <?= $form->field($modelAdd, "[{$i}]age")->textInput(['maxlength' => true, 'style' => 'width:5em']); ?>

                        <?= $form->field($modelAdd, "[{$i}]gender")->dropDownList(ArrayHelper::map(MasterGender::find()->all(), 'gender_id', 'gender_name'), ['prompt' => 'Gender', 'style' => 'width:7em']) ?>

                        <?= $form->field($modelAdd, "[{$i}]id_proof_type")->dropDownList(ArrayHelper::map(MasterIdProof::find()->all(), 'proof_id', 'proof_name'), ['prompt' => 'ID Proof', 'style' => 'width:8em']) ?>

                        <?= $form->field($modelAdd, "[{$i}]id_proof_number")->textInput(['maxlength' => true, 'style' => 'width:10em']) ?> <br/>

                        <div class="pull-right">
                            <button type="button" class="add-item btn btn-success btn-xs"><i class="glyphicon glyphicon-plus"></i> Add Another Traveler</button>
                            <button type="button" class="remove-item btn btn-danger btn-xs"><i class="glyphicon glyphicon-minus"></i> Remove</button>
                        </div><br/><br/>
                        <!--</div>-->
                    </div><!-- .row -->
                </div>
            </div>
<?php endforeach; ?>
<?php DynamicFormWidget::end(); ?>

        <!--    $form->field($model, 'user_id')->textInput()-->

        <!--    $form->field($model, 'booking_datetime')->textInput()-->

        <div class="panel-heading"><h3 class="panel-title">Accommodation Details</h3></div>
        <div class="panel-body">

            <?=
            $form->field($model3, 'two_Bedded', [
                'addon' => [
                    'append' => [
                        'content' => '<i class="glyphicon glyphicon-bed"></i> <i class="glyphicon glyphicon-bed"></i>'
                    ]
                ]
            ])->textInput(['style' => 'width:9em'])
            ?>

            <?=
            $form->field($model3, 'three_Bedded', [
                'addon' => [
                    'append' => [
                        'content' => '<i class="glyphicon glyphicon-bed"></i> <i class="glyphicon glyphicon-bed"></i>  <i class="glyphicon glyphicon-bed"></i>'
                    ]
                ]
            ])->textInput(['style' => 'width:9em'])
            ?>

        </div>

        <div class="panel-heading"><h3 class="panel-title">Emergency Contact Details ( Non - Traveler )</h3></div>
        <div class="panel-body">

            <?= $form->field($model, 'emergency_contact')->textInput(['maxlength' => true]) ?> 

            <?= $form->field($model, 'emergency_email')->textInput(['maxlength' => true]) ?> 

        </div>

        <div class="panel-heading"><h3 class="panel-title">Payment Details</h3></div>
        <div class="panel-body">

            <div id="payment-block">
                <label class="adult_dp">Adult: <span id="ad_price"></span> x <span id="adult_count"></span> = <span id="adult_price"></span></label>
                <label class="kid_dp">Kid: 8000 x <span id="kid_count"></span> = <span id="kid_price"></span></label>
                <label class="infant_dp">Infant: 2500 x <span id="infant_count"></span> = <span id="infant_price"></span></label><br/>
            </div>

            <?php $list = [1 => 'Credit Card', 2 => 'Debit Card', 3 => 'Net Banking', 4 => 'Cash On Delivery', 5 => 'Payment at Office']; ?>

            <?= $form->field($model, 'total_amount')->textInput(['maxlength' => true,'readonly' => true]) ?><br/><br/>
            
             <?= $form->field($model, 'mode_of_payment')->radioList($list) ?> <br/>

        </div>
        <!--    $form->field($model, 'agent_id')->textInput()-->
        <div class="panel-body">
            <div class="form-group text-center">
                <?= $form->field($model, 'agree')->checkbox() ?><br/>
        <?= Html::submitButton($model->isNewRecord ? 'Book!' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
            </div>
        </div>
<?php ActiveForm::end(); ?>
    </div>
</div>