<?php

use yii\helpers\Html;
//use yii\widgets\ActiveForm;
use kartik\form\ActiveForm;
use yii\helpers\ArrayHelper;
use frontend\models\Tours;
use frontend\models\MasterGender;
use frontend\models\MasterIdProof;

/* @var $this yii\web\View */
/* @var $model frontend\models\Bookings */
/* @var $form ActiveForm */
$this->title = 'Bookings';
$this->params['breadcrumbs'][] = $this->title;
?>
<?php
$form = ActiveForm::begin([
            'type' => ActiveForm::TYPE_INLINE,
            'formConfig' => ['showErrors' => true]
        ]);
?>

<div class="bookings">
    <div class="panel panel-default"><br/><br/>
        <div class="panel-body text-center">

            <?= $form->field($model, 'tour_id')->dropDownList(ArrayHelper::map(Tours::find()->all(), 'tour_id', 'departure_date'), ['prompt' => 'Select Tour Date']) ?>

        </div>
        <div class="panel-heading"><h3 class="panel-title">Passenger Details</h3></div>
        <div class="panel-body">

            <?= $form->field($model2, 'firstname') ?>

            <?= $form->field($model2, 'middlename') ?>

            <?= $form->field($model2, 'lastname') ?>

            <?= $form->field($model2, 'age') ?>

            <?= $form->field($model2, 'gender')->dropDownList(ArrayHelper::map(MasterGender::find()->all(), 'gender_id', 'gender_name'), ['prompt' => 'Select Gender']) ?>

            <?= $form->field($model2, 'id_proof_type')->dropDownList(ArrayHelper::map(MasterIdProof::find()->all(), 'proof_id', 'proof_name'), ['prompt' => 'Select ID Proof']) ?>

        </div>

        <div class="panel-heading"><h3 class="panel-title">Accommodation Details</h3></div>
        <div class="panel-body">
            <?= $form->field($model3, 'two_Bedded') ?>

            <?= $form->field($model3, 'three_Bedded') ?>
        </div>

        <div class="panel-heading"><h3 class="panel-title">Contact Details</h3></div>
        <div class="panel-body">

            <?= $form->field($model2, 'emergency_contact') ?>
            <!--    $form->field($model, 'user_id')  -->

            <!--    $form->field($model, 'booking_datetime') -->
        </div>

        <div class="panel-heading"><h3 class="panel-title">Payment Details</h3></div>
        <div class="panel-body">

            <?php $list = [0 => 'Credit Card', 1 => 'Debit Card', 2 => 'Net Banking', 3 => 'Cash On Delivery', 4 => 'Payment at Office']; ?>

            <?= $form->field($model, 'mode_of_payment')->radioList($list); ?><br/>

            <?= $form->field($model, 'total_amount') ?>

            <!--    $form->field($model, 'agent_id')  -->

            <!--    $form->field($model, 'booking_status') -->
        </div>
        <div class="panel-body">       
            <div class="form-group">
                <?= $form->field($model, 'agree')->checkbox() ?><br/>
                <?= Html::submitButton('BOOK NOW !', ['class' => 'btn btn-primary']) ?>
            </div>
            <?php ActiveForm::end(); ?>
        </div>
    </div>
</div>
<!-- bookings -->
