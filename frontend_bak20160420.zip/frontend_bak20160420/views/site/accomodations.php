<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model frontend\models\Accomodations */
/* @var $form ActiveForm */
?>
<div class="accomodations">

    <?php $form = ActiveForm::begin(); ?>

        <?= $form->field($model, 'booking_id') ?>
        <?= $form->field($model, 'two_Bedded') ?>
        <?= $form->field($model, 'three_Bedded') ?>
    
        <div class="form-group">
            <?= Html::submitButton('Submit', ['class' => 'btn btn-primary']) ?>
        </div>
    <?php ActiveForm::end(); ?>

</div><!-- accomodations -->
