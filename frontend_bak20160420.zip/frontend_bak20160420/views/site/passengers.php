<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model frontend\models\Passengers */
/* @var $form ActiveForm */
?>
<div class="passengers">

    <?php $form = ActiveForm::begin(); ?>

<!--        $form->field($model, 'user_id')-->
        <?= $form->field($model, 'firstname') ?>
        <?= $form->field($model, 'lastname') ?>
        <?= $form->field($model, 'age') ?>
        <?= $form->field($model, 'gender') ?>
        <?= $form->field($model, 'id_proof_type') ?>
<!--        $form->field($model, 'booking_id')-->
    
        <div class="form-group">
            <?= Html::submitButton('Submit', ['class' => 'btn btn-primary']) ?>
        </div>
    <?php ActiveForm::end(); ?>

</div><!-- passengers -->
