<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model frontend\models\Accomodations */

$this->title = 'Update Accomodations: ' . ' ' . $model->accomodation_id;
$this->params['breadcrumbs'][] = ['label' => 'Accomodations', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->accomodation_id, 'url' => ['view', 'id' => $model->accomodation_id]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="accomodations-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
